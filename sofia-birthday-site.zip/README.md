# 🎀 Sofia Birthday Website

Un site static, roz și glittery făcut pentru ziua Sofiei.

## Cum îl pui pe GitHub Pages

1. Creează un repository nou pe GitHub.
2. Încarcă `index.html`, `style.css` și `script.js`.
3. Intră în **Settings → Pages**.
4. La **Build and deployment**, alege **Deploy from a branch**.
5. Alege branch-ul `main` și folderul `/root`.
6. Salvează și așteaptă câteva momente.
7. GitHub îți va afișa linkul site-ului.

Nu are nevoie de server sau Node.js. Este un site static.

## Personalizare

- Textul principal este în `index.html`.
- Culorile și designul sunt în `style.css`.
- Quiz-ul, popup-urile și animațiile sunt în `script.js`.
- Pentru informații astronomice exacte, poți completa ora și localitatea nașterii Sofiei în secțiunea „Cerul din ziua în care te-ai născut”.
