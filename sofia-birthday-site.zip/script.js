const questions = [
  ["Îți place să ai totul pus la punct?", ["Da, evident 😌", "Uneori", "Haosul e stilul meu"]],
  ["Observi imediat când ceva nu e în regulă?", ["ABSOLUT", "De obicei", "Doar dacă e foarte evident"]],
  ["Ai tendința să analizezi prea mult lucrurile?", ["Poate... sau poate prea mult 😭", "Uneori", "Nu prea"]],
  ["Îți place să ajuți oamenii pe care îi iubești?", ["Da, mereu ❤️", "De cele mai multe ori", "Depinde"]],
  ["Ai standarde foarte înalte?", ["Da 🙄", "Uneori", "Nu chiar"]]
];

const quiz = document.getElementById("quiz");
questions.forEach((q, i) => {
  const box = document.createElement("div");
  box.className = "question";
  box.innerHTML = `<p>${i+1}. ${q[0]}</p>` + q[1].map((a,j) =>
    `<label><input type="radio" name="q${i}" value="${j}"> ${a}</label>`).join("");
  quiz.appendChild(box);
});

document.getElementById("quizButton").addEventListener("click", () => {
  let score = 0, answered = 0;
  questions.forEach((_,i) => {
    const selected = document.querySelector(`input[name="q${i}"]:checked`);
    if (selected) { score += 2 - Number(selected.value); answered++; }
  });
  const result = document.getElementById("quizResult");
  if (answered < questions.length) {
    result.textContent = "Răspunde la toate întrebările întâi, domnișoară Fecioară 👀";
    return;
  }
  const messages = [
    "Fecioară undercover. Te-ai descurcat prea bine. ♍✨",
    "Destul de Fecioară cât să fie suspect. 💗",
    "Fecioară level: MAXIMUM. Nimic nu scapă de tine. 👑✨"
  ];
  result.textContent = messages[score >= 8 ? 2 : score >= 5 ? 1 : 0];
});

const modal = document.getElementById("placeModal");
const modalTitle = document.getElementById("modalTitle");
const modalText = document.getElementById("modalText");

document.querySelectorAll(".place-card").forEach(card => {
  card.addEventListener("click", () => {
    modalTitle.textContent = card.dataset.title;
    modalText.textContent = card.dataset.text;
    modal.classList.add("open");
    modal.setAttribute("aria-hidden","false");
  });
});

document.querySelector(".modal-close").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if(e.target === modal) closeModal(); });
function closeModal(){ modal.classList.remove("open"); modal.setAttribute("aria-hidden","true"); }

const start = new Date("2019-08-27T00:00:00");
const end = new Date("2026-08-27T00:00:00");
const days = Math.round((end - start) / 86400000);
document.getElementById("daysCounter").textContent = days.toLocaleString("ro-RO");

const sparkles = document.querySelector(".sparkles");
for(let i=0;i<24;i++){
  const s=document.createElement("span");
  s.textContent = Math.random() > .5 ? "✦" : "·";
  s.style.position="fixed";
  s.style.left=Math.random()*100+"vw";
  s.style.top=Math.random()*100+"vh";
  s.style.color="#fff";
  s.style.fontSize=(8+Math.random()*14)+"px";
  s.style.opacity=.25+Math.random()*.65;
  s.style.animation=`float ${4+Math.random()*7}s ease-in-out ${-Math.random()*6}s infinite`;
  s.style.pointerEvents="none";
  s.style.zIndex="1";
  sparkles.appendChild(s);
}
