SITE PENTRU SOFIA 💗

1. Deschide index.html într-un browser ca să vezi site-ul.
2. Folderul images trebuie să rămână lângă index.html.
3. Pentru a-l transforma într-un link public, încarcă întreg folderul pe un serviciu de hosting static.

Pozele folosite sunt cele încărcate în conversație.
Secțiunea astronomică este bazată pe data 27 august 2009 și este decorativă deoarece ora nașterii nu este cunoscută.
